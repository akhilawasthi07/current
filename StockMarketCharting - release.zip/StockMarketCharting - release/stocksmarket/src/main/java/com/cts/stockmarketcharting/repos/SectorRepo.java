package com.cts.stockmarketcharting.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.stockmarketcharting.entity.Sector;

public interface SectorRepo extends JpaRepository<Sector, Integer> {
	
	public Sector findSectorBySectorName(String name);
	
	

}
