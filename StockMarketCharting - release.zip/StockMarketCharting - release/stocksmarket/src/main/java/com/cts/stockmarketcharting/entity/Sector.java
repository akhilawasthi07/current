package com.cts.stockmarketcharting.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "sector")
@NamedQuery(name = "Sector.findSectorBySectorName",
query = "SELECT s FROM Sector s where Sector_name =: name")
public class Sector {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sector_id")
	private int id;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Sector_name")
	private String name;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "sector_about")
	private String about;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public Sector(int id, String name, String about) {
		super();
		this.id = id;
		this.name = name;
		this.about = about;
	}

	public Sector() {
		super();
	}

	@Override
	public String toString() {
		return "Sector [id=" + id + ", name=" + name + ", about=" + about + "]";
	}
	
	
}
