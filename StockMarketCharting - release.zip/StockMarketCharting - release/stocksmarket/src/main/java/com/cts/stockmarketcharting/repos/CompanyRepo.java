package com.cts.stockmarketcharting.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.stockmarketcharting.entity.Company;

public interface CompanyRepo extends JpaRepository<Company, Integer> {
	
	public Company findCompanyByCompanyName(String name);
	
	public List<Company> findAllActivatedCompany();
	
	public Company findById(int id);

}