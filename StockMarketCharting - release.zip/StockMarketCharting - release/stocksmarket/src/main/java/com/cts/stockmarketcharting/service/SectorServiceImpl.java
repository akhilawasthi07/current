package com.cts.stockmarketcharting.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.stockmarketcharting.entity.Sector;
import com.cts.stockmarketcharting.repos.SectorRepo;

@Service
public class SectorServiceImpl implements SectorService {
	
	@Autowired
	SectorRepo sectorRepo;

	@Override
	public void addSector(Sector sector) {
		
		sectorRepo.save(sector);
	}

}
